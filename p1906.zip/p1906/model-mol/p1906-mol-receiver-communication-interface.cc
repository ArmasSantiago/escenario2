/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 *  Copyright � 2014 by IEEE.
 *
 *  This source file is an essential part of IEEE P1906.1,
 *  Recommended Practice for Nanoscale and Molecular
 *  Communication Framework.
 *  Verbatim copies of this source file may be used and
 *  distributed without restriction. Modifications to this source
 *  file as permitted in IEEE P1906.1 may also be made and
 *  distributed. All other uses require permission from the IEEE
 *  Standards Department (stds-ipr@ieee.org). All other rights
 *  reserved.
 *
 *  This source file is provided on an AS IS basis.
 *  The IEEE disclaims ANY WARRANTY EXPRESS OR IMPLIED INCLUDING
 *  ANY WARRANTY OF MERCHANTABILITY AND FITNESS FOR USE FOR A
 *  PARTICULAR PURPOSE.
 *  The user of the source file shall indemnify and hold
 *  IEEE harmless from any damages or liability arising out of
 *  the use thereof.
 *
 * Author: Giuseppe Piro - Telematics Lab Research Group
 *                         Politecnico di Bari
 *                         giuseppe.piro@poliba.it
 *                         telematics.poliba.it/piro
 **************************************************************
 * Santiago Armas
 * sdarmas.fie@unach.edu.ec
 * 2023
 **************************************************************
 */


#include "ns3/log.h"

#include "p1906-mol-receiver-communication-interface.h"
#include "ns3/p1906-net-device.h"
#include <ns3/packet.h>
#include "ns3/p1906-specificity.h"
#include "ns3/p1906-message-carrier.h"
#include "ns3/p1906-communication-interface.h"
#include "ns3/p1906-medium.h"
#include "ns3/p1906-net-device.h"
#include "ns3/p1906-motion.h"
#include "p1906-mol-specificity.h"
#include "ns3/mobility-model.h"
#include <stddef.h>
#include <stdio.h>
#include <stdint.h>

namespace ns3 {

NS_LOG_COMPONENT_DEFINE ("P1906MOLReceiverCommunicationInterface");

TypeId P1906MOLReceiverCommunicationInterface::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::P1906MOLReceiverCommunicationInterface")
    .SetParent<P1906ReceiverCommunicationInterface> ();
  return tid;
}

P1906MOLReceiverCommunicationInterface::P1906MOLReceiverCommunicationInterface ()
{
  NS_LOG_FUNCTION (this);
}

P1906MOLReceiverCommunicationInterface::~P1906MOLReceiverCommunicationInterface ()
{
  NS_LOG_FUNCTION (this);
}

void
P1906MOLReceiverCommunicationInterface::HandleReception (Ptr<P1906CommunicationInterface> src, Ptr<P1906CommunicationInterface> dst, Ptr<P1906MessageCarrier> message)
{
  std::string strRXBITS = "";
  std::string strCAPMOL = "";
  NS_LOG_FUNCTION (this << "===Sección-Proceso de Recepción===");
  Ptr<P1906MOLSpecificity> specificity = GetP1906Specificity ()->GetObject<P1906MOLSpecificity> ();
  bool isRxOk = specificity->CheckRxCompatibility (src, dst, message);
  if (isRxOk)
    {
          NS_LOG_FUNCTION (this << "Mensaje recibido correctamente");
	  Ptr<Packet> p = message->GetMessage ();
	  NS_LOG_FUNCTION (this << "Recibiendo el paquete [id,size]" << p->GetUid() << p->GetSize ());
	  //xxx forward to upper layer
	  #define MLB (UINT8_MAX /2+1)
	  int PaqueteRX = int(p->GetSize());
	  int BER=0;
	  std::vector <std::vector<int> > BITS_RX(PaqueteRX, std::vector<int>(8));
	  std::vector <std::vector<int> > BITS_TX(PaqueteRX, std::vector<int>(8));
	  BITS_RX = message->GetModulation();
	  uint8_t *buffer = new uint8_t[PaqueteRX];
	  double UMBRAL_RX = static_cast<double>(BITS_RX[0][0]);
          for(int i = 0; i < PaqueteRX; i++) {
             for(int j = 0; j < 7; j++) {
                UMBRAL_RX = std::max(UMBRAL_RX, static_cast<double>(BITS_RX[i][j+1]));
             }
          }
          UMBRAL_RX = static_cast<int>(std::ceil(static_cast<float>(UMBRAL_RX) / 2));
          for (int i = 0; i < PaqueteRX; i++) {
          buffer[i] = 0;
          for (int j = 0; j < 8; j++) {
              if (BITS_RX[i][j] > UMBRAL_RX) {
                 strRXBITS += '1';
                 strCAPMOL += std::to_string(BITS_RX[i][j]) + "||";
                 buffer[i] |= (1 << j);
              if (BITS_TX[i][j] != m_molecules) {
                 BER++;
              } 
              } else {
                strRXBITS += '0';
                strCAPMOL += std::to_string(BITS_RX[i][j]) + "||";
                if (BITS_TX[i][j] != 0) {
                   BER++;
                }
                }
                NS_LOG_FUNCTION("[Concentración Máxima por bit:]" << BITS_RX[i][j]);
              }
              NS_LOG_FUNCTION("[Secuencia Recibida:]" << strRXBITS);
            }
            Ptr<Packet> message = Create<Packet>(buffer, PaqueteRX);
            NS_LOG_FUNCTION("[Número de Error_Bits:]" << BER);
            NS_LOG_FUNCTION("[Umbral en RX:]" << UMBRAL_RX);
            NS_LOG_FUNCTION("[BIT_ERROR_RATE (BER):]" << (float)BER / (float)(PaqueteRX*8));
            
    }
  else
    {
	  NS_LOG_FUNCTION (this << "Mensaje NO recibido correctamente");
	  //ignore the message carrier
    }
    
}
void
P1906MOLReceiverCommunicationInterface::SetMolecules (double q)
{
 NS_LOG_FUNCTION (this << q);
 m_molecules = q;
}

double
P1906MOLReceiverCommunicationInterface::GetMolecules (void)
{
 NS_LOG_FUNCTION (this);
 return m_molecules;
}

} // namespace ns3
